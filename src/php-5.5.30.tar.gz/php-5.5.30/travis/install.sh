#!/bin/bash
sudo apt-get install re2c libgmp-dev libicu-dev libmcrypt-dev libtidy-dev
